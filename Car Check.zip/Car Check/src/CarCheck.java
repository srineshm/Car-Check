import java.util.Scanner;

public class CarCheck {

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		int carnum;
		
		System.out.print("What is your car model number? ");
		carnum = input.nextInt();
		
		if (carnum == 119 || carnum == 179 || (carnum >= 189 && carnum <= 195) || carnum == 221 || carnum == 780) {
			System.out.println("Your car is defective. It must be repaired. ");
			
		} 
		
		else {
				System.out.println("Your car is fine.");
			}
		}

	}


